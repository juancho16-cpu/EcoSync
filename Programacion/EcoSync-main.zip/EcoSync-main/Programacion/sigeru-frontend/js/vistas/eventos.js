
function leerArgumentos(texto) {
    if (!texto) {
        return [];
    }
    return texto.split(",").map(function (parte) {
        const valor = parte.trim();
        if (valor === "true") {
            return true;
        }
        if (valor === "false") {
            return false;
        }
        if (valor !== "" && !isNaN(valor)) {
            return Number(valor);
        }
        return valor;
    });
}

function llamarFuncion(nombre, elemento) {
    const funcion = window[nombre];
    if (typeof funcion !== "function") {
        console.error("No existe la funcion " + nombre);
        return;
    }
    funcion(...leerArgumentos(elemento.dataset.args));
}

document.addEventListener("click", function (evento) {
    const elemento = evento.target.closest("[data-click]");
    if (!elemento) {
        return;
    }
    if (elemento.tagName === "A") {
        evento.preventDefault();
    }
    llamarFuncion(elemento.dataset.click, elemento);
});

document.addEventListener("change", function (evento) {
    const elemento = evento.target.closest("[data-change]");
    if (elemento) {
        llamarFuncion(elemento.dataset.change, elemento);
    }
});

document.addEventListener("input", function (evento) {
    const elemento = evento.target.closest("[data-input]");
    if (elemento) {
        llamarFuncion(elemento.dataset.input, elemento);
    }
});
