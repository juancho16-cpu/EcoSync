
function icono(nombre) {
    return `<svg class="icono" aria-hidden="true"><use href="img/iconos.svg#${nombre}"></use></svg>`;
}

function mostrarMensaje(texto, esError) {
    const caja = document.getElementById("mensaje");
    caja.textContent = texto;
    if (esError) {
        caja.className = "mensaje error";
    } else {
        caja.className = "mensaje ok";
    }
}

function limpiarTexto(texto) {
    if (texto == null) return "";
    return String(texto)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;");
}

function mostrarDatosUsuario(usuario) {
    document.getElementById("nombreUsuario").textContent = usuario.nombre;
    document.getElementById("rolUsuario").textContent = usuario.rol;

    if (usuario.rol != "Administrador") {
        ocultar("solo-admin");
    }

    if (usuario.rol != "Administrador" && usuario.rol != "Operario") {
        ocultar("solo-gestion");
    }

    if (usuario.rol == "Vecino") {
        ocultar("no-vecino");
    }

    if (usuario.rol != "Vecino") {
        ocultar("solo-vecino");
    }
}

function ocultar(clase) {
    const elementos = document.querySelectorAll("." + clase);
    for (const elemento of elementos) {
        elemento.style.display = "none";
    }
}

function abrirModal() {
    const modal = document.getElementById("formModal");
    modal.showModal();
}

function cerrarModal() {
    const modal = document.getElementById("formModal");
    modal.close();
}

function colorEstado(estado) {
    if (estado == "Funcional" || estado == "Operativo" || estado == "Operativa" || estado == "Disponible" || estado == "Resuelta" || estado == "Activo") return "";
    if (estado == "En mantenimiento" || estado == "En reparación" || estado == "En ruta" || estado == "En proceso" || estado == "Pendiente" || estado == "Sin verificar") return "alerta";
    return "mal";
}

function colorPrioridad(prioridad) {
    if (prioridad == "Alta") return "mal";
    if (prioridad == "Media") return "alerta";
    return "";
}

function mesActual() {
    return fechaDeHoy().substring(0, 7);
}

function descargarCSV(nombreArchivo, filas) {
    let texto = "";
    for (const fila of filas) {
        const celdas = [];
        for (const celda of fila) {
            celdas.push('"' + String(celda ?? "").replaceAll('"', '""') + '"');
        }
        texto += celdas.join(";") + "\r\n";
    }

    const archivo = new Blob(["\uFEFF" + texto], { type: "text/csv;charset=utf-8" });
    const enlace = document.createElement("a");
    enlace.href = URL.createObjectURL(archivo);
    enlace.download = nombreArchivo;
    enlace.click();
    URL.revokeObjectURL(enlace.href);
}

function diasEntre(desde, hasta) {
    const unDia = 24 * 60 * 60 * 1000;
    return Math.round((new Date(hasta) - new Date(desde)) / unDia);
}

function buscarPorId(lista, id) {
    for (const item of lista) {
        if (item.id == id) {
            return item;
        }
    }
    return null;
}

function contarHasta(idElemento, numero) {
    const elemento = document.getElementById(idElemento);
    const final = Number(numero);
    let actual = 0;
    const paso = Math.max(1, Math.ceil(final / 20));
    const reloj = setInterval(function () {
        actual = actual + paso;
        if (actual >= final) {
            actual = final;
            clearInterval(reloj);
        }
        elemento.textContent = actual;
    }, 30);
}

function fechaLarga() {
    return new Date().toLocaleDateString("es-UY", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}

function fechaDeHoy() {
    const hoy = new Date();
    let mes = hoy.getMonth() + 1;
    let dia = hoy.getDate();
    if (mes < 10) mes = "0" + mes;
    if (dia < 10) dia = "0" + dia;
    return hoy.getFullYear() + "-" + mes + "-" + dia;
}
