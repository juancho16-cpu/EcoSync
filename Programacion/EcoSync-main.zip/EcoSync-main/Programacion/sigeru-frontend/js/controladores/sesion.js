
let usuarioLogueado = null;

async function revisarSesion() {
    try {
        const respuesta = await obtenerSesion();
        usuarioLogueado = respuesta.usuario;
    } catch (error) {
        window.location.href = "index.html";
        return false;
    }

    mostrarDatosUsuario(usuarioLogueado);
    mostrarContadorAlertas();
    await aplicarIdioma();

    revisarMensajes();
    setInterval(revisarMensajes, 15000);
    return true;
}

async function aplicarIdioma() {
    try {
        const parametros = await obtenerParametros();
        for (const p of parametros) {
            if (p.nombre == "idioma") {
                traducirPagina(p.valor);
            }
        }
    } catch (error) {
    }
}

let ultimoMensaje = null; // id de la notificacion mas nueva que ya vimos

async function revisarMensajes() {
    try {
        const datos = await obtenerMensajes();
        mostrarContadorMensajes(datos.sin_leer);
        mostrarListaMensajes(datos.mensajes);

        let masNueva = null;
        for (const m of datos.mensajes) {
            if (masNueva == null || Number(m.id) > Number(masNueva.id)) {
                masNueva = m;
            }
        }

        if (masNueva != null && ultimoMensaje != null && Number(masNueva.id) > ultimoMensaje && masNueva.leido == 0) {
            mostrarAvisoEmergente(masNueva);
        }
        if (masNueva != null) {
            ultimoMensaje = Number(masNueva.id);
        } else {
            ultimoMensaje = 0;
        }
    } catch (error) {
    }
}

function abrirNotificaciones() {
    const panel = document.getElementById("panelNotificaciones");
    panel.classList.toggle("abierto");

    if (panel.classList.contains("abierto")) {
        revisarMensajes();
    }
}

async function abrirMensaje(id, enlace) {
    try {
        await marcarMensajeLeido(id);
    } catch (error) {
    }
    window.location.href = enlace;
}

async function leerTodos() {
    try {
        await marcarMensajeLeido(null);
        revisarMensajes();
    } catch (error) {
        mostrarMensaje(error.message, true);
    }
}

async function mostrarContadorAlertas() {
    const contador = document.getElementById("contadorAlertas");
    if (contador == null) return;

    try {
        const alertas = await obtenerAlertas();
        if (alertas.length > 0) {
            contador.textContent = alertas.length;
            contador.style.display = "inline-block";
        }
    } catch (error) {
    }
}

function puedeEditar() {
    return usuarioLogueado.rol == "Administrador" || usuarioLogueado.rol == "Operario";
}

async function salir() {
    await cerrarSesion();
    window.location.href = "index.html";
}
