
async function pedirAlServidor(url, metodo = "GET", datos = null) {
    const opciones = { method: metodo };

    if (datos != null) {
        opciones.headers = { "Content-Type": "application/json" };
        opciones.body = JSON.stringify(datos);
    }

    let respuesta;
    try {
        respuesta = await fetch(url, opciones);
    } catch (error) {
        throw new Error("No se pudo conectar con el servidor");
    }

    const json = await respuesta.json();

    if (respuesta.status == 401 && json.error.includes("se cerró") && !location.pathname.endsWith("index.html")) {
        alert(json.error);
        location.href = "index.html";
    }

    if (!respuesta.ok) {
        throw new Error(json.error);
    }
    return json;
}
