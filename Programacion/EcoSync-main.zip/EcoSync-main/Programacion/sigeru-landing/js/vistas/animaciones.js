
const barra = document.getElementById("navbar");
if (barra) {
    window.addEventListener("scroll", function () {
        if (window.scrollY > 40) {
            barra.classList.add("con-fondo");
        } else {
            barra.classList.remove("con-fondo");
        }
    });
}

const partes = document.querySelectorAll(".aparecer");
if ("IntersectionObserver" in window) {
    const observador = new IntersectionObserver(function (entradas) {
        for (const entrada of entradas) {
            if (entrada.isIntersecting) {
                entrada.target.classList.add("visible");
                observador.unobserve(entrada.target);
            }
        }
    }, { threshold: 0.15 });

    for (const parte of partes) {
        observador.observe(parte);
    }
} else {
    for (const parte of partes) {
        parte.classList.add("visible");
    }
}

const video = document.querySelector(".hero-video");
if (video) {
    video.addEventListener("error", function () {
        video.remove();
    }, true);
    const fuente = video.querySelector("source");
    if (fuente) {
        fuente.addEventListener("error", function () {
            video.remove();
        });
    }
}
