
async function enviarRegistro(datos) {
    const respuesta = await fetch(API_USUARIOS + "/registro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
    });
    const json = await respuesta.json();

    if (!respuesta.ok) {
        throw new Error(json.error);
    }
    return json;
}

async function enviarVerificacion(codigo) {
    const respuesta = await fetch(API_USUARIOS + "/verificar?codigo=" + encodeURIComponent(codigo));
    const json = await respuesta.json();

    if (!respuesta.ok) {
        throw new Error(json.error);
    }
    return json;
}
