const API_USUARIOS = "/sigeru-api-usuarios/api.php";
const URL_FRONTEND = "/sigeru-frontend/index.html";
